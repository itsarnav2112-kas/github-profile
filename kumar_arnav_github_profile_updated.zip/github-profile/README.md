<div align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="./dark.svg">
    <source media="(prefers-color-scheme: light)" srcset="./light.svg">
    <img src="./dark.svg" alt="Kumar Arnav GitHub developer profile" width="100%">
  </picture>
</div>

<h1 align="center">Hi, I'm Kumar Arnav 👋</h1>

<p align="center">
  <strong>3rd-Year Computer Science Engineering Student</strong><br>
  Developer in progress · Web Development · AI/ML
</p>

<p align="center">
  I enjoy learning by building practical projects and exploring how software can solve real problems.
</p>

---

## About Me

- 🎓 Computer Science Engineering student in my 3rd year.
- 💻 Interested in web development and software development.
- 🤖 Exploring AI/ML through practical projects.
- 🌱 Continuously improving my programming and problem-solving skills.

## What I'm Building

### [AI Resume Analyzer](https://github.com/itsarnav2112-kas/AI-RESUME-ANALYZER)

A web project focused on analyzing uploaded resumes and presenting useful feedback, including skills and keyword insights.

**Technologies used in the project:** HTML, CSS, JavaScript, Python/Flask.

## Tech Stack

<p>
  <img alt="HTML5" src="https://img.shields.io/badge/HTML5-E34F26?style=flat-square&logo=html5&logoColor=white">
  <img alt="CSS3" src="https://img.shields.io/badge/CSS3-1572B6?style=flat-square&logo=css3&logoColor=white">
  <img alt="JavaScript" src="https://img.shields.io/badge/JavaScript-F7DF1E?style=flat-square&logo=javascript&logoColor=black">
  <img alt="Python" src="https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white">
  <img alt="Flask" src="https://img.shields.io/badge/Flask-000000?style=flat-square&logo=flask&logoColor=white">
  <img alt="Git" src="https://img.shields.io/badge/Git-F05032?style=flat-square&logo=git&logoColor=white">
  <img alt="GitHub" src="https://img.shields.io/badge/GitHub-181717?style=flat-square&logo=github&logoColor=white">
</p>

## Technical Interests

- Web development
- AI/ML and practical AI-powered tools
- Programming and problem solving
- Building useful student projects

## GitHub

Explore my repositories and current work:

[![GitHub](https://img.shields.io/badge/GitHub-itsarnav2112--kas-181717?style=for-the-badge&logo=github)](https://github.com/itsarnav2112-kas)

## Connect

- GitHub: [@itsarnav2112-kas](https://github.com/itsarnav2112-kas)

---

<p align="center"><sub>Learn continuously. Build thoughtfully. Improve every day.</sub></p>
